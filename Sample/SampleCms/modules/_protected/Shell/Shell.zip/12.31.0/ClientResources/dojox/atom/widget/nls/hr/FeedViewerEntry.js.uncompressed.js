define(
"dojox/atom/widget/nls/hr/FeedViewerEntry", ({
	deleteButton: "[Izbriši]"
})
);
