//>>built
define("dijit/form/nls/ar/validate",({invalidMessage:"القيمة التي تم ادخالها غير صحيحة.",missingMessage:"يجب ادخال هذه القيمة.",rangeMessage:"هذه القيمة ليس بالمدى الصحيح."}));