define(
"dojox/atom/widget/nls/ar/FeedEntryEditor", ({
	doNew: "[جديد]",
	edit: "[تحرير]",
	save: "[حفظ]",
	cancel: "[الغاء]"
})
);
